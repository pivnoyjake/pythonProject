# WNHelper
A Discord bot for Majestic RP Weazel News Discord servers. 
